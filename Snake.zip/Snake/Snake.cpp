#include "Snake.h"

/**
* This class implements the movement of a snake on a monocrome display.
*
* @author David Monninger, Siemens AG (P&O IE SPE BO SW KHE)
* @version 1.0
*/


/**
* Helper function to roll over a value between a max value and 0
* 
* @param value - the value to roll over
* @param max - the maximum value
* 
* @returns the rolled over value
*/
unsigned int Snake::rollOver(int value, int max)
{
	if (value < 0)
	{
		return max - 1;
	}
	if (value >= max)
	{
		return 0;
	}
	return value;
}


/**
* Constructor for a snake on a canvas of given size
* 
* @param xMax - canvas size in x
* @param yMax - canvas size in y
*/
Snake::Snake(unsigned int xMax, unsigned int yMax)
{
	// update the attributes
	this->xMax = xMax;
	this->yMax = yMax;
	// calculate maximum length of snake (when the snake fills the whole canvas
	this->snakeLength = (long)xMax * (long)yMax;

	// allocate memory for Snake ans display arrays
	snake = (SnakeLink*)malloc(sizeof(SnakeLink) * snakeLength);

	display = (bool**)malloc(sizeof(bool*) * xMax);
	for (size_t i = 0; i < xMax; i++)
	{
		display[i] = (bool*)malloc(sizeof(bool) * yMax);
	}
	
}


/**
* Destructor
*/
Snake::~Snake()
{
	// free the previously allocated memory
	free(snake);
	for (size_t i = 0; i < xMax; i++)
	{
		free(display[i]);
	}
	free(display);
}

/**
* Initialize the snake at the given coordinates
* 
* @param startX - initial x coordinate
* @param startY - initial y coordinate
*/
void Snake::begin(int startX = 0, int startY = 0)
{
	// enable the first snake link and set its coordinates
	start = 0;
	end = 0;
	snake[start].filled = true;
	snake[start].x = startX;
	snake[start].y = startY;

}


/**
* Move the snake in the given x or y direction. During the move, the snake can get longer by one link
* 
* @param x - the amount to mave in x
* @param y - the abount to move in y
* @param grow - if true, the snake grows during the move
* 
* @return true, if the snake ran into itself, false otherwise
*/
bool Snake::move(int x, int y, bool grow)
{
	//determine next coordinates
	unsigned int xNew = rollOver((snake[start].x + x), xMax);
	unsigned int yNew = rollOver((snake[start].y + y), yMax);

	// move start forward
	start = (start + 1) % snakeLength;
	// activate new start link and set coordinates
	snake[start].filled = true;
	snake[start].x = xNew;
	snake[start].y = yNew;
	if (!grow)
	{
		// move the end link one forward, deactivate the old end link
		snake[end].filled = false;
		end = (end + 1) % snakeLength;
	}

	//check for collision
	return isSnake(snake[start].x, snake[start].y);
}


/**
* Getter function for the x coordinate of the head of the snake
* 
* @return the x coordinate
*/
int Snake::getX()
{
	return snake[start].x;
}

/**
* Getter function for the y coordinate of the head of the snake
* 
* @return the y coordinate
*/
int Snake::getY()
{
	return snake[start].y;
}


/**
* Checks if a given coordinate is filled by the snake
* 
* @param x - x-coordinate of the point to be checked
* @param y - y-coordinate of the point to be checked
*/
bool Snake::isSnake(int x, int y)
{
	// check if a point of the snake matches
	for (size_t i = end; i != start; i = (i + 1) % snakeLength)
	{
		if ((x == snake[i].x) && (y == snake[i].y) && snake[i].filled)
		{
			return true;
		}
	}
	return false;
}


/**
* Update the internal representation of the display to reflect the snake object. Must be called after move, otherwise getDisplay() gives outdated results.
*/
void Snake::update()
{
	// clear the display
	for (size_t i = 0; i < xMax; i++)
	{
		for (size_t j = 0; j < yMax; j++)
		{
			display[i][j] = false;
		}
	}

	// fill the corresponding point of the display if it is occupied by an active snake link
	for (size_t i = 0; i < snakeLength; i++)
	{
		display[snake[i].x][snake[i].y] |= snake[i].filled;
	}
}


/**
* Returns the state of the display at a given point
* 
* @param x - the x-coordinate of the point
* @param y - the y-coordinate of the point
* 
* @return the state of the display at that point
*/
byte Snake::getDisplay(int x, int y)
{
	return display[x][y];
}

/**
* Resets the snake to length 0 and to the given coordinates
* 
* @param startX - initial x coordinate
* @param startY - initial y coordinate
*/
void Snake::reset(int startX = 0, int startY = 0)
{
	for (size_t i = 0; i < snakeLength; i++)
	{
		snake[i].filled = false;
	}
	begin(startX, startY);
	update();
}
