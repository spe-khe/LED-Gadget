var searchData=
[
  ['off',['OFF',['../class_m_d___m_a_x72_x_x.html#a0dff60785ecf2d1a0dddf9f6f077a6d9',1,'MD_MAX72XX']]],
  ['on',['ON',['../class_m_d___m_a_x72_x_x.html#af5481fa994efb897c9cb418f8ba19096',1,'MD_MAX72XX']]]
];
