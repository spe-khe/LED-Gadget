#pragma once
#include <Arduino.h>

/**
* This class implements the movement of a snake on a monocrome display.
* 
* @author David Monninger, Siemens AG (P&O IE SPE BO SW KHE)
* @version 1.0
*/
class Snake
{
	// struct for a single pixel of the snake
	struct SnakeLink
	{
		// whether the snake link is active
		bool filled = 0;

		// coordinates of the snake link
		uint8_t x = 0;
		uint8_t y = 0;
	};

private:
	unsigned int start;	// index of the first snake link
	unsigned int end;	// index of the last snake link

	// display extents
	unsigned int xMax;
	unsigned int yMax;

	unsigned long snakeLength;	// max length of the snake

	SnakeLink *snake;	// the snake 
	bool **display;		// array of bool for the display

	/**
	* Helper function to roll over a value between a max value and 0
	*
	* @param value - the value to roll over
	* @param max - the maximum value
	*
	* @returns the rolled over value
	*/
	unsigned int rollOver(int value, int max);
	
public:
	/**
	* Constructor for a snake on a canvas of given size
	*
	* @param xMax - canvas size in x
	* @param yMax - canvas size in y
	*/
	Snake(unsigned int xMax, unsigned int yMax);


	/**
	* Destructor
	*/
	~Snake();


	/**
	* Initialize the snake at the given coordinates
	*
	* @param startX - initial x coordinate
	* @param startY - initial y coordinate
	*/
	void begin(int startX, int startY);


	/**
	* Move the snake in the given x or y direction. During the move, the snake can get longer by one link
	*
	* @param x - the amount to mave in x
	* @param y - the abount to move in y
	* @param grow - if true, the snake grows during the move
	*
	* @return true, if the snake ran into itself, false otherwise
	*/
	bool move(int x, int y, bool grow);


	/**
	* Getter function for the x coordinate of the head of the snake
	*
	* @return the x coordinate
	*/
	int getX();


	/**
	* Getter function for the y coordinate of the head of the snake
	*
	* @return the y coordinate
	*/
	int getY();


	/**
	* Checks if a given coordinate is filled by the snake
	*
	* @param x - x-coordinate of the point to be checked
	* @param y - y-coordinate of the point to be checked
	*/
	bool isSnake(int x, int y);


	/**
	* Update the internal representation of the display to reflect the snake object. Must be called after move, otherwise getDisplay() gives outdated results.
	*/
	void update();


	/**
	* Returns the state of the display at a given point
	*
	* @param x - the x-coordinate of the point
	* @param y - the y-coordinate of the point
	*
	* @return the state of the display at that point
	*/	byte getDisplay(int x, int y);


	/**
	* Resets the snake to length 0 and to the given coordinates
	*
	* @param startX - initial x coordinate
	* @param startY - initial y coordinate
	*/
	void reset(int startX, int startY);

	


};