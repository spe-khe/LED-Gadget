var searchData=
[
  ['copyright_295',['Copyright',['../page_copyright.html',1,'']]]
];
