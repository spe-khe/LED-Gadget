var _m_d___parola_8cpp =
[
    [ "STATIC_ZONES", "_m_d___parola_8cpp.html#a965a7b1afe7b3cc96fdeae578bcb1e21", null ]
];