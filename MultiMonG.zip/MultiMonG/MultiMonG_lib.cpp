
#include "MultiMonG_lib.h"

//----------------------------------------Clock-Class--------------------------------------
// Constructor
Clock::Clock(int initSecondsAfterMidnight) {
    this->secondsAfterMidnight = initSecondsAfterMidnight;
}

// Getter for the current time
void Clock::getTime(char *outStr) {
    // divide the time into hours and minutes
    int minutes = this->secondsAfterMidnight / 60 % 60;
    int hours = this->secondsAfterMidnight / 3600;
    // make the ":" between hours and minutes blink
    char division;
    if (secondsAfterMidnight % 2) {
        division = ':';
    } else {
        division = ' ';
    }
    // convert the time to a string in the format "hh:mm"
    sprintf(outStr, "%02d%c%02d", hours, division, minutes);
}

// Increments the time by one second
//@formatter:off (So my IDE doesn't destroy everything)
void ICACHE_RAM_ATTR Clock::incrementSeconds() {
    this->secondsAfterMidnight++;
}
//@formatter:on

// Setter for the time
void Clock::setTime(int hour, int minute, int second) {
    this->secondsAfterMidnight = hour * 3600 + minute * 60 + second;
}

// Setter for the timer duration
void Clock::setTimer(int duration) {
    this->timerDuration = duration;
}

// Starts the timer
void Clock::startTimer() {
    if (!timerActive) {
        this->timerStart = this->secondsAfterMidnight;
        this->timerActive = true;
    } else {
        // stop the timer if it is already active
        this->timerActive = false;
    }
}

// Whether the timer is expired
bool Clock::timerExpired() {
    if (this->timerActive) {
        if (this->secondsAfterMidnight - this->timerStart >= this->timerDuration) {
            this->timerActive = false;
            return true;
        }
    }
    return false;
}

// Getter for the remaining time
void Clock::getTimer(char *outStr) {
    int minutes;
    int hours;
    char division;
    // calculate the remaining time if the timer is active
    if (timerActive) {
        // calculate the remaining time
        int timerRemaining = this->timerDuration - (this->secondsAfterMidnight - this->timerStart);
        // divide the time into hours and minutes
        minutes = timerRemaining / 60 % 60;
        hours = timerRemaining / 3600;

        // make the ":" between hours and minutes blink
        if (this->secondsAfterMidnight % 2) {
            division = ':';
        } else {
            division = ' ';
        }
    } else {
        // if the timer is not active, show the timer duration
        // divide the time into hours and minutes
        minutes = timerDuration / 60 % 60;
        hours = timerDuration / 3600;
        // display a static ":" between hours and minutes
        division = ':';
    }
    // convert the time to a string in the format "hh:mm"
    sprintf(outStr, "%02d%c%02d", hours, division, minutes);
}


//----------------------------------------AirQuality-Class--------------------------------------
// Constructor
AirQuality::AirQuality(int pin) {
    this->pin = pin;
    this->value = 0;
}

// Getter for the air quality value
int AirQuality::getAirQuality(double temperature, double humidity) {

    // Durchschnittswert über 100 Messungen berechnen
    int readingSum = 0;
    for (int i = 0; i < 100; i++) {
        readingSum += analogRead(this->pin);
    }

    // Durchschnittswert berechnen
    double reading = ((double) readingSum / 100.0);
    // Widerstand des Sensors berechnen
    double resistance = 1023 * RLOAD / reading;

    // Korrekturwert aufgrund von Temperatur und Luftfeuchtigkeit berechnen
    double correctionFactor = CORA * temperature * temperature - CORB * temperature + CORC - (humidity - 33.) * CORD;
    // Korrigierten Widerstand berechnen
    double correctedResistance = resistance / correctionFactor;

    // ppm-Wert berechnen
    this->value = PARA * pow((correctedResistance / RZERO), -PARB);

    return this->value;
}


//----------------------------------------Melody-Class--------------------------------------
// Constructor
Melody::Melody(int pin, int *melody, int duration) {
    this->pin = pin;
    this->melody = melody;
    this->duration = duration;
}

// Sets up the output pin
void Melody::begin() {
    pinMode(this->pin, OUTPUT);
}

// Plays the melody
bool Melody::play() {
    // check if the melody is finished (the end of the array is reached or the note is 0)
    if (((this->currentNote) >= 12) || (this->melody[this->currentNote] == 0)) {
        // get back to the beginning of the melody
        this->currentNote = 0;
        // stop the buzzer from buzzing
        digitalWrite(this->pin, LOW);
        // return true to indicate that the melody is finished
        return true;
    }

    // calculate the period of the note in microseconds
    unsigned long period = 1000000.0 / (double) this->melody[currentNote];
    unsigned long currentTime = micros();
    // calculate the current state with the modulo operator to get a square wave
    bool state = (currentTime % period) < (period / 2.0);

    // set the buzzer pin to this state
    digitalWrite(this->pin, state);

    // Continue with the next note if the note duration has passed
    if (currentTime / 1000.0 - this->lastNoteChange > this->duration) {
        this->lastNoteChange = currentTime / 1000.0;
        this->currentNote++;
    }
    // return false to indicate that the melody is not finished
    return false;

}

// Resets the melody
void Melody::reset() {
    this->currentNote = 0;
    digitalWrite(this->pin, LOW);
}
