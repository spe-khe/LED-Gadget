var searchData=
[
  ['parola_20library_297',['Parola Library',['../page_software.html',1,'']]]
];
