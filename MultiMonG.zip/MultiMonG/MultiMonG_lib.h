/**
 * This library implements the functionality of a clock, timer, Air quality sensor and music player. It is written for
 * the MultiMonG - Multi-Monitoring-Gadget of SPE Karlsruhe.
 *
 * Siemens AG, 05/2022 - DM
 */

#ifndef MULTIMONG_LIB_H
#define MULTIMONG_LIB_H

#include "Arduino.h"


class Clock {
private:
    /// The time in seconds since the start of the day
    int secondsAfterMidnight;
    /// The time at which the timer was started
    int timerStart;
    /// The duration of the timer
    int timerDuration = 65;
    /// Whether the timer is currently running
    bool timerActive;
public:
    /**
     * Constructor
     *
     * @param initSecondsAfterMidnight initial time in seconds after midnight
     */
    explicit Clock(int initSecondsAfterMidnight);

    //@formatter:off (Stops my IDE from screwing up the function signature)
    /**
     * Increments the time by one second - should be called every second
     */
    void ICACHE_RAM_ATTR incrementSeconds();
    //@formatter:on

    /**
     * Sets the current time to the given value
     *
     * @param hour the hour to set
     * @param minute the minute to set
     * @param second the second to set
     */
    void setTime(int hour, int minute, int second);

    /**
     * Returns the current time as a String in the format HH:MM.
     *
     * @param outStr the char array[5] to write the time to
     */
    void getTime(char *outStr);

    /**
     * Sets the timer duration to the given value.
     *
     * @param duration the duration in seconds
     */
    void setTimer(int duration);

    /**
     * Starts the timer.
     */
    void startTimer();

    /**
     * Returns the currently remaining time in as a String in the format HH:MM.
     *
     * @param outStr  the char array[5] to write the time to
     */
    void getTimer(char *outStr);

    /**
     * Returns true if the timer is expired, resetting it if it is.
     *
     * @return true if the timer is expired
     */
    bool timerExpired();
};


/// defines for interpreting the value of the air quality sensor
// The load resistance on the board
#define RLOAD 1.0
// Calibration resistance at atmospheric CO2 level
#define RZERO 76.63
// Parameters for calculating ppm of CO2 from sensor resistance
#define PARA 116.6020682
#define PARB 2.769034857

// Parameters to model temperature and humidity dependence
#define CORA 0.00035
#define CORB 0.02718
#define CORC 1.39538
#define CORD 0.0018

class AirQuality {
private:
    /// The pin the sensor is connected to
    int pin;
    /// The current value of the sensor
    int value;
public:
    /**
     * Constructor
     *
     * @param pin the pin the sensor is connected to
     */
    AirQuality(int pin);

    /**
     * Returns the current value of the sensor
     *
     * @param temperature the current temperature for compensation
     * @param humidity the current humidity for compensation
     *
     * @return the current value of the sensor
     */
    int getAirQuality(double temperature, double humidity);
};

/// Notes to make the melody easier to set:
#define NOTE_A3  220
#define NOTE_AS3 233
#define NOTE_B3  247
#define NOTE_C4  262
#define NOTE_CS4 277
#define NOTE_D4  294
#define NOTE_DS4 311
#define NOTE_E4  330
#define NOTE_F4  349
#define NOTE_FS4 370
#define NOTE_G4  392
#define NOTE_GS4 415
#define NOTE_A4  440
#define NOTE_AS4 466
#define NOTE_B4  494
#define NOTE_C5  523
#define NOTE_CS5 554
#define NOTE_D5  587
#define NOTE_DS5 622
#define NOTE_E5  659
#define NOTE_F5  698
#define NOTE_FS5 740
#define NOTE_G5  784
#define NOTE_GS5 831
#define NOTE_A5  880
#define NOTE_AS5 932
#define NOTE_B5  988
#define NOTE_C6  1047
#define NOTE_CS6 1109
#define NOTE_D6  1175
#define NOTE_DS6 1245
#define NOTE_E6  1319
#define NOTE_F6  1397
#define NOTE_FS6 1480
#define NOTE_G6  1568
#define NOTE_GS6 1661
#define NOTE_A6  1760
#define NOTE_AS6 1865
#define NOTE_B6  1976
#define NOTE_C7  2093
#define NOTE_CS7 2217
#define NOTE_D7  2349
#define NOTE_DS7 2489
#define NOTE_E7  2637
#define NOTE_F7  2794
#define NOTE_FS7 2960
#define NOTE_G7  3136
#define NOTE_GS7 3322
#define NOTE_A7  3520

class Melody {
private:
    /// The pin the buzzer is connected to
    int pin;
    /// Pointer to the array of notes
    int *melody;
    /// duration of each note
    unsigned int duration = 500;
    /// time of the last note change
    unsigned long lastNoteChange = 0;
    /// index of the current note
    int currentNote = 0;

public:
    /**
     * Constructor
     *
     * @param pin the pin the buzzer is connected to
     * @param melody the array of notes
     * @param duration the duration of each note
     */
    Melody(int pin, int *melody, int duration);

    /**
     * Sets up the pin the buzzer is connected to.
     */
    void begin();

    /**
     * Plays the melody.
     *
     * @return true if the melody is finished
     */
    bool play();

    /**
     * Resets the melody, sets the output pin to low so the buzzer stops buzzing
     */
    void reset();
};


#endif //MULTIMONG_LIB_H
